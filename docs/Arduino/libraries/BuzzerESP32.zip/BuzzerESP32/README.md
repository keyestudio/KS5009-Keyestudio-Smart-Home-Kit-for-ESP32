Buzzer library for ESP32
